import feedparser as fp
from source.models.NewsModel import NewsModel
from dateutil import parser as dateParser
from datetime import datetime
from source.models.EventModel import EventModel

import unittest

NEWS_FEED_SOURCE = 'https://www.uni-saarland.de/universitaet/aktuell/news.html?type=9818&L=0&cat=47'
EVENTS_FEED_SOURCE = 'https://www.uni-saarland.de/universitaet/aktuell/veranstaltungen.html?type=9818&L=0&cat=50'

class NewsParser:
    def parseNews(self, dataRSS: str):
        """
        parses an RSS string that is obtained from the university news rss feed and returns a
        list of NewsModel objects containing all news items given in dataRSS
        :param dataRSS: an rss string containing university news
        :return a list of news items
        """
        newsList = []
        rss = fp.parse(dataRSS)
        items = rss['items']
        for item in items:
            title = item['title']
            publishedDate = dateParser.parse(item['published'])
            link = item['link']  # this seems to be empty in all of the uni news
            categories = []
            for tag in item['tags']:
                categories.append(tag['term'])
            description = item['description']
            content = item['content']
            imageLink = None
            for link in item['links']:
                if 'image' in link['type']:
                    imageLink = link['href']
            newsItem = NewsModel(title, publishedDate, link, categories, description, content, imageLink)
            # print(newsItem)
            newsList.append(newsItem)
        return newsList


# TODO these are very much alike, maybe merge them somehow


class EventsParser:
    def parseEvents(self, dataRSS: str):
        """
        parses an RSS string that is obtained from the university events rss feed and returns a
        list of EventModel objects containing all news items given in dataRSS
        :param dataRSS: an rss string containing university events
        :return a list of events items
        """
        eventsList = []
        rss = fp.parse(dataRSS)
        items = rss['items']
        for item in items:
            title = item['title']
            publishedDate = datetime.now()
            happeningDate = dateParser.parse(item['published'])
            link = item['link']  # this seems to be empty in all of the uni events
            categories = []
            for tag in item['tags']:
                categories.append(tag['term'])  # for now, this might be 'events' for all events
            description = item['description']
            content = item['content']  # this might also be empty for all events
            imageLink = None
            for link in item['links']:
                if 'image' in link['type']:
                    imageLink = link['href']
            eventItem = EventModel(title, publishedDate, happeningDate, link, categories, description, content,
                                   imageLink)
            eventsList.append(eventItem)
        return eventsList


class EventsFeedTestCase(unittest.TestCase):


    # this test case is to check if the news feed rss link is functional and if it is returning data
    def test_rss_source_functionality(self):
        events_feed_rss = fp.parse(EVENTS_FEED_SOURCE)
        self.assertGreater(len(events_feed_rss['items']), 0)

    # this test is to check if the number of news feed entries parsed is equal to the raw news feed entries
    def test_num_parsed_rss_entries(self):
        eventsParser = EventsParser()
        events_feed_rss = fp.parse(EVENTS_FEED_SOURCE)
        newsList = eventsParser.parseEvents(EVENTS_FEED_SOURCE)
        self.assertEqual(len(newsList), len(events_feed_rss['items']))


if __name__ == '__main__':
    unittest.main()